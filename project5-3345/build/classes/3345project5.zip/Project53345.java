/*
Mary Grace Doviak
CS 3345
Section 004
Spring 2019
Project 5
Program implements different versions of the QuickSort algorithm with 4 different options for the pivot. 
In the report file, it outputs the array size, and the time in nanoseconds for each different pivot strategy. 
The sorted and unsorted files contain the sorted and unsorted arrays, in that order. 
 */
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;
import java.util.ArrayList;

public class Project53345 {

    public static void main(String[] args) throws FileNotFoundException {
        int siz = Integer.parseInt(args[0]);

        // create random arrayLists
        ArrayList<Integer> arrayList1 = QuickSorter.generateRandomList(siz);
        ArrayList<Integer> arrayList2 = new ArrayList<Integer>(arrayList1);
        ArrayList<Integer> arrayList3 = new ArrayList<Integer>(arrayList1);
        ArrayList<Integer> arrayList4 = new ArrayList<Integer>(arrayList1);

        
        PrintWriter reportFile = null;
        try { // see if reportFile was made properly
            reportFile = new PrintWriter(args[1]);
        } catch (IOException e) {
            System.out.println("Could not find file");
        }
        reportFile.println("Array Size = " + siz);

        
        PrintWriter unsortedList = null;
        try { // see if unsortedList was made properly
            unsortedList = new PrintWriter(args[2]);
        } catch (IOException e) {
            System.out.println("Could not find file");
        }
        for (int i = 0; i < arrayList1.size(); i++) {
            unsortedList.print(arrayList1.get(i) + " ");
        }
        unsortedList.println();


        
        PrintWriter sortedList = null;
        try { // see if sortedList was made properly
            sortedList = new PrintWriter(args[3]);
        } catch (IOException e) {
            System.out.println("Could not find file");
        }

        
        
        try {
            // sorts using the first element
            QuickSorter.PivotStrategy choice = QuickSorter.PivotStrategy.FIRST_ELEMENT;
            Duration time = QuickSorter.timedQuickSort(arrayList1, choice);
            reportFile.println("FIRST_ELEMENT : " + time);
            for (int i = 0; i < arrayList1.size(); i++) {
                sortedList.print(arrayList1.get(i) + " ");
            }
            sortedList.println();

        } catch (NullPointerException e) {
            System.out.println("Could not sort the list by first element");
        }

        try {
            // sorts using a random element
            QuickSorter.PivotStrategy choice = QuickSorter.PivotStrategy.RANDOM_ELEMENT;
            Duration time = QuickSorter.timedQuickSort(arrayList2, choice);
            reportFile.println("RANDOM_ELEMENTS : " + time);
            for (int i = 0; i < arrayList2.size(); i++) {
                sortedList.print(arrayList2.get(i) + " ");
            }
            sortedList.println();

        } catch (NullPointerException e) {
            System.out.println("Could not sort the list by random element");
        }

        try {
            // sorts using the median of three random elements
            QuickSorter.PivotStrategy choice = QuickSorter.PivotStrategy.MEDIAN_OF_THREE_RANDOM_ELEMENTS;
            Duration time = QuickSorter.timedQuickSort(arrayList3, choice);
            reportFile.println("MEDIAN_OF_THREE_RANDOM_ELEMENTS : " + time);
            for (int i = 0; i < arrayList3.size(); i++) {
                sortedList.print(arrayList3.get(i) + " ");
            }
            sortedList.println();

        } catch (NullPointerException e) {
            System.out.println("Could not sort the file by the median of three random elements");
        }

        try {
            // sorts using the median of three elements
            QuickSorter.PivotStrategy choice = QuickSorter.PivotStrategy.MEDIAN_OF_THREE_ELEMENTS;
            Duration time = QuickSorter.timedQuickSort(arrayList4, choice);
            reportFile.println("MEDIAN_OF_THREE_ELEMENTS : " + time);
            for (int i = 0; i < arrayList4.size(); i++) {
                sortedList.print(arrayList4.get(i) + " ");
            }
            sortedList.println();

        } catch (NullPointerException e) {
            System.out.println("Could not sort the file by the median of three elements");
        }
        // close all files
        reportFile.close();
        unsortedList.close();
        sortedList.close();
    }
}
