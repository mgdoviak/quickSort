/*
Mary Grace Doviak
CS 3345
Section 004
Spring 2019
Project 5
Program implements different versions of the QuickSort algorithm with 4 different options for the pivot. 
In the report file, it outputs the array size, and the time in nanoseconds for each different pivot strategy. 
The sorted and unsorted files contain the sorted and unsorted arrays, in that order. 
 */
import java.time.Duration;
import java.util.ArrayList;
import java.util.Random;

public class QuickSorter {

    public static enum PivotStrategy {
        FIRST_ELEMENT,
        RANDOM_ELEMENT,
        MEDIAN_OF_THREE_RANDOM_ELEMENTS,
        MEDIAN_OF_THREE_ELEMENTS
    }
    
    public static <E extends Comparable<E>> void swap(ArrayList<E> list, int int1, int int2) {
        E e = list.get(int1);
        list.set(int1, list.get(int2));
        list.set(int2, e);
    }

    public static <E extends Comparable<E>> Duration timedQuickSort(ArrayList<E> list, PivotStrategy pivotStrategy) throws NullPointerException {
        if (list == null || pivotStrategy == null) 
            throw new NullPointerException();
        // start recording time
        long start = System.nanoTime();

        // check which strategy to use
        if (pivotStrategy == PivotStrategy.FIRST_ELEMENT) 
            QuickSortFirst(list, 0, list.size() - 1); 
        else if (pivotStrategy == PivotStrategy.RANDOM_ELEMENT) 
            QuickSortRandom(list, 0, list.size() - 1);
        else if (pivotStrategy == PivotStrategy.MEDIAN_OF_THREE_RANDOM_ELEMENTS) 
            QuickSortRandomMedianOfThree(list, 0, list.size() - 1);
        else 
            QuickSortMedianOfThree(list, 0, list.size() - 1);

        // stop recording time
        long end = System.nanoTime();

        Duration time = Duration.ofNanos(end - start);
        return time;
    }

    public static ArrayList<Integer> generateRandomList(int size) throws IllegalArgumentException {
        if (size < 0) 
            throw new IllegalArgumentException();

        ArrayList<Integer> randomList = new ArrayList<Integer>(size);
        Random r = new Random();

        // add on random numbers
        for (int i = 0; i < size; i++) 
            randomList.add(r.nextInt());

        return randomList;
    }

    public static <E extends Comparable<E>> void insertionSort(ArrayList<E> list, int int1, int int2) {
        int j;
        for (int i = int1 + 1; i <= int2; i++) {
            E e = list.get(i);
            for (j = i; j > int1 && e.compareTo(list.get(j - 1)) < 0; j--) 
                list.set(j, list.get(j - 1));
            list.set(j, e);
        }
    }

    public static <E extends Comparable<E>> void QuickSortFirst(ArrayList<E> list, int left, int right) {
        if (left < right + 1) { // continue recursion 
            int pivotNeighbor = left + 1;
            // put everything smaller than pivot to the left of it and everything bigger than the pivot to the right of it 
            for (int i = pivotNeighbor; i <= right; i++) {
                if (list.get(i).compareTo(list.get(left)) < 0) 
                    swap(list, i, pivotNeighbor++);
            }
            //swap pivot with most recent pivotNeighbor
            swap(list, left, pivotNeighbor - 1);
            // sort everything to the right of pivot 
            QuickSortFirst(list, pivotNeighbor, right);
            // sort everything to the left of pivot
            QuickSortFirst(list, left, pivotNeighbor - 2);
        } 
        else if (left + 20 > right)// stop recursion, base case
            insertionSort(list, left, right);
    }

    public static <E extends Comparable<E>> void QuickSortRandom(ArrayList<E> list, int left, int right) {
        if (left < right + 1) { // continue recursion 
            swap(list, left, makeRandomPivot(left, right));
            int pivotNeighbor = left + 1;
            // put everything smaller than pivot to the left of it and everything bigger than the pivot to the right of it 
            for (int i = pivotNeighbor; i <= right; i++) {
                if (list.get(i).compareTo(list.get(left)) < 0) 
                    swap(list, i, pivotNeighbor++);
            }
            // swap pivot with most recent pivotNeighbor
            swap(list, left, pivotNeighbor - 1);
            // sort everything to the right
            QuickSortRandom(list, pivotNeighbor, right);
            // sort everything to the left
            QuickSortRandom(list, left, pivotNeighbor - 2);
        } // if positions are already correct
        else if (left + 20 > right) // stop recursion, base case
            insertionSort(list, left, right);
    }

    public static <E extends Comparable<E>> int makeRandomPivot(int left, int right) {
        Random r = new Random();
        // makes sure pivot is between left and right
        int randomPivot = left + r.nextInt((right - left) + 1);
        return randomPivot;
    }

    public static <E extends Comparable<E>> void MedianOfThree(ArrayList<E> list, int left, int right) {
        // find median index
        int center = (left + right) / 2;
        // if right is less than center, swap them 
        if (list.get(right).compareTo(list.get(center)) < 0) 
            swap(list, center, right);
        // if center is less than right, swap them
        if (list.get(right).compareTo(list.get(left)) < 0) 
            swap(list, left, right);
        // if center is less than left, swap them
        if (list.get(center).compareTo(list.get(left)) < 0) 
            swap(list, left, center);
        swap(list, center, left);
    }

    public static <E extends Comparable<E>> void QuickSortMedianOfThree(ArrayList<E> list, int left, int right) {
        if (left < right + 1) { // continue recursion 
            MedianOfThree(list, left, right);
            int pivotNeighbor = left + 1;
            // put everything smaller than pivot to the left of it and everything bigger than the pivot to the right of it 
            for (int i = pivotNeighbor; i <= right; i++) {
                if (list.get(i).compareTo(list.get(left)) < 0)
                    swap(list, i, pivotNeighbor++);
            }
            // swap pivot with most recent pivotNeighbor
            swap(list, left, pivotNeighbor - 1);
            // sort everything to the right
            QuickSortMedianOfThree(list, pivotNeighbor, right);
            // sort everything to the left
            QuickSortMedianOfThree(list, left, pivotNeighbor - 2);
        } 
        if (left + 20 > right) // stop recursion, base case
            insertionSort(list, left, right);
    }

    public static <E extends Comparable<E>> void QuickSortRandomMedianOfThree(ArrayList<E> list, int left, int right) {
        if (left < right + 1) { // continue recursion
            RandomMedian(list, left, right);
            int pivotNeighbor = left + 1;
            // put everything smaller than pivot to the left of it and everything bigger than the pivot to the right of it 
            for (int i = pivotNeighbor; i <= right; i++) {
                if (list.get(i).compareTo(list.get(left)) < 0) 
                    swap(list, i, pivotNeighbor++);
            }
            // swap pivot with most recent pivotNeighbor
            swap(list, left, pivotNeighbor - 1);
            // sort everything to the right
            QuickSortRandomMedianOfThree(list, pivotNeighbor, right);	
            // sort everything to the left
            QuickSortRandomMedianOfThree(list, left, pivotNeighbor - 2);	
        }
        else if (left + 20 > right) // stop recursion, base case
             insertionSort(list, left, right);
    }

    public static <E extends Comparable<E>> void RandomMedian(ArrayList<E> list, int left, int right) {
        Random r = new Random();
        // find 3 random indexes
        int index1 = left + r.nextInt((right - left) + 1);
        int index2 = left + r.nextInt((right - left) + 1);
        int index3 = left + r.nextInt((right - left) + 1);

        if (index1 > index3 && list.get(index1).compareTo(list.get(index3)) < 0) 
            swap(list, index1, index3);
        if (index2 > index3 && list.get(index2).compareTo(list.get(index3)) < 0) 
            swap(list, index2, index3);
        if (index1 > index2 && list.get(index1).compareTo(list.get(index2)) < 0) 
            swap(list, index1, index2);
        
        swap(list, index2, left);
    }
}
